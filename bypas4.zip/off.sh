su -c iptables -F
su -c iptables -X
su -c iptables -F
su -c iptables --flush
iptables -F
iptables -X
iptables -F
iptables --flush
